new Vue({ 
	el:'#app', 
	data: { 
		article:{
			id: 0,
			title: '',
			content: ''
		},
		articles:[{
			id:1,
			title: 'Today',
			content: 'content content content content content content '
		},{
			id:2,
			title: 'The beauty of CSS',
			content: 'content content content content content content '
		},{
			id:3,
			title: 'php is the best language of the program world',
			content: 'best best best best best best best best'
		},{
			id:4,
			title: 'Can H5 replace apps?',
			content: 'xxxxxxxxxxxxxxxxxxxx'
		}]
	},
	methods: {
		addUser:function(){
			this.user.id = this.users.length + 1;
			this.users.push(this.user);
			this.user = "";
		},
		removeUser:function(user){
			this.users.$remove(user);
		},
		sortBy:function(param){
			this.sortParam = param;
		}
	}
});
